def convert_height(current_height):
	return 480 - current_height	
