# PiRower
PiRower is a python racing game for a rowing machine which runs on a Raspberry Pi. 

# To use this software
To use this software you will need:-
 - a rowing machine that is compatible with a Delta Air Rower. 
 - A pi2 or better running raspian Jessie

This software also requires a custom made hardware device. The details of this device have not yet been made available, but it is essentially a plastic disc with a strip of aluminium foil which spins through 3 infrared break beam sensors.

